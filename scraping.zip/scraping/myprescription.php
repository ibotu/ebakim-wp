<?php 
include "header.php";
use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);


$year = array("2023", "2022");

$date=[];
$prescriptionno=[];
$prescriptiontype=[];
$physician=[];
$SYSTakipNo=[];
$allsystakipno=[];
for($j = 0;$j < count($year);$j++) {
    $myprescription[$j]=$client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaGoreReceteGetir?year='.$year[$j].'');
    $date[] = $myprescription[$j]->filter('tr td:nth-child(1)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $prescriptionno[] = $myprescription[$j]->filter('tr td:nth-child(2)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $prescriptiontype[] = $myprescription[$j]->filter('tr td:nth-child(3)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $physician[] = $myprescription[$j]->filter('tr td:nth-child(4)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $SYSTakipNo[] = $myprescription[$j]->filterXPath('//tr/td/a')->each(function (Crawler $node, $i){
            return $node->attr('href');
    
       
    });
}

for($j = 0;$j < count($year);$j++) {
    for($s = 0;$s < count($SYSTakipNo[$j]);$s++) {
     
        $records=explode(",",$SYSTakipNo[$j][$s]);
        $sysid=str_replace("javascript:ReceteDetay('","",$records[0]);
        $finalsysid = substr($sysid, 0, -1);
        $allsystakipno[]=$finalsysid;

    }
}


?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Prescription Number</th>
      <th scope="col">Prescription Type</th>
      <th scope="col">Physician</th> 
    </tr>
  </thead>
  <tbody>
    <?php 
for($j = 0;$j < count($year);$j++) {
    for($n = 0;$n < count($date[$j]);$n++) {
        ?>
    <tr>
        <td><?php echo trim($date[$j][$n]);?> </td>
        <td><?php echo trim($prescriptionno[$j][$n]);?></td>
        <td><?php echo $prescriptiontype[$j][$n];?></td>
        <td><?php echo $physician[$j][$n];?>
    
    <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne-<?php echo $j."-".$n;?>" aria-expanded="false" aria-controls="flush-collapseOne">
      Show Details
      </button>
    </h2>
    <div id="flush-collapseOne-<?php echo $j."-".$n;?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
      <div class="prescrived drugs details">
        <h3>PRESCRIBED DRUGS</h3>
            <?php
            $query='{"SYSTakipNo":+"'.trim($allsystakipno[$n]).'","ReceteNo":"'.trim($prescriptionno[$j][$n]).'"}';
            
            $url='https://enabiz.gov.tr/HastaBilgileri/ReceteDetay?data='.$query.'';

                $crawler = $client->request('GET', $url);

                $jsonResponse = $client->getResponse()->getContent();

                $data = json_decode($jsonResponse, true);
                  //print_r($data['ilacList']);
                  echo '<table class="table">
                    <thead>
                        <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Barcode</th>
                        <th scope="col">Medicine Name</th>
                        <th scope="col">Hospital Name</th>
                        <th scope="col">Clinic</th>
                        
                        <th scope="col">Dosage</th>
                        <th scope="col">Period</th>
                        <th scope="col">Period Type</th>
                        <th scope="col">Usage Method</th>
                        <th scope="col">Usage Number</th>
                        <th scope="col">Box Count</th>
                        </tr>
                    </thead>
                    <tbody>';
                        if(!empty($data['ilacList'])) {
                            for($d = 0;$d < count($data['ilacList']);$d++) {
                                //echo "Barkcode:".$data['ilacList'][$d]['barkod']."<br>";
                                ?>
                                            <tr>
                                            <td scope="row"><?php echo trim($data['ilacList'][$d]['tarih']);?></td>
                                            <td scope="row"><?php echo trim($data['ilacList'][$d]['barkod']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['ilacAdi']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['hastaneAdi']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['bransAdi']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['doz']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['periyod']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['periyodTipi']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['kullanimSekli']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['kullanimSayisi']);?></td>
                                            <td><?php echo trim($data['ilacList'][$d]['kutuAdet']);?></td>
                                            </tr>
                                    <?php
                            }
                        }
                        else
                        {
                            echo "<tr><td>You do not have any registered data.</td></tr>";
                        }
                    echo '</tbody>
                    </table>';
            ?>
            <h3>PURCHASED DRUGS</h3>
            <div class="purchased-drugs">
             <?php 

                    echo '<table class="table">
                    <thead>
                        <tr>
                        <th scope="col">Barcode</th>
                        <th scope="col">Medicine Name</th>
                        <th scope="col">Box Count</th>
                        </tr>
                    </thead>
                    <tbody>';
                    if(!empty($data['satilanIlacList'])) {
                        for($d = 0;$d < count($data['satilanIlacList']);$d++) {
                            //echo "Barkcode:".$data['ilacList'][$d]['barkod']."<br>";
                            ?>
                                        <tr>
                                    
                                        <td scope="row"><?php echo trim($data['satilanIlacList'][$d]['barkod']);?></td>
                                        <td><?php echo trim($data['satilanIlacList'][$d]['ilacAdi']);?></td>
                                        <td><?php echo trim($data['satilanIlacList'][$d]['kutuAdet']);?></td>
                                        </tr>
                                        <?php
                        }
                    }
                    else
                    {
                        echo "<tr><td>You do not have any registered data.</td></tr>";
                    }
                    echo '</tbody>
                    </table>';
                 ?>
                                
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
    </td>
        
    </tr>
    <?php
    }
}
?>
</tbody>
</table>
</div>
<?php 
/* Get prescription more details */
$query='{"SYSTakipNo":+"2BTEXT1DN7RZT617Y5V47","ReceteNo":"1XA10SR"}';

$url='https://enabiz.gov.tr/HastaBilgileri/ReceteDetay?data='.$query.'';

$crawler = $client->request('GET', $url);

$jsonResponse = $client->getResponse()->getContent();

$data = json_decode($jsonResponse, true);
if (json_last_error() === JSON_ERROR_NONE) {
    //print_r($data);
} else {
    echo "Error parsing JSON data: " . json_last_error_msg();
}
/*Get prescription mode details code end */
?>