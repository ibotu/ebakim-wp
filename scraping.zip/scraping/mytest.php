<?php 
include "header.php";
use Symfony\Component\DomCrawler\Crawler;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);
$year = array("startdate"=>"2022", "enddate"=>"2023");
$store=[];
    $mytests = $client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaraGoreTahlilGetir?baslangicTarihi='.$year['startdate'].'&bitisTarihi='.$year['enddate'].'');
    //$id[] = $mytests[$j]->filterXPath('//tr/td/i')->attr('title');
   
    $institutioname = $mytests->filterXPath('//tr')->each(function (Crawler $node, $i){
        //return $node->attr('title');
        $record=trim($node->attr('class'));
        if($record=='trParentBgOpen')
        {
            return $node->filterXPath('//tr/td/i')->attr('title');
        //return $i;
        }
    });
    $processname = $mytests->filter('tr > td:nth-child(3)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $result = $mytests->filter('tr > td:nth-child(4)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $resultunit = $mytests->filter('tr > td:nth-child(5)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $referencevalue = $mytests->filter('tr > td:nth-child(6)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $date = $mytests->filter('tr > td:nth-child(9)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    

//print_r($institutioname);

?>

<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Institution Name</th>
      <th scope="col">Process Name</th>
      <th scope="col">Result</th>
      <th scope="col">Result Unit</th> 
      <th scope="col">Reference Value</th>
      <th scope="col">Date</th> 
    </tr>
  </thead>
  <tbody>
    
    <?php 
    for($n = 0;$n < count($processname);$n++) {

        ?>
    <tr>
        
    <td><?php if(isset($institutioname[$n])!='') {
        unset($store);
    echo trim($institutioname[$n]);
    $store[]=trim($institutioname[$n]);
}
else
{
    echo $store[0];
}
?> </td>
        <td><?php echo trim($processname[$n]);?></td>
        <td><?php echo trim($result[$n]);?></td>
        <td><?php echo trim($resultunit[$n]);?></td>
        <td><?php echo trim($referencevalue[$n]);?></td>
        <td><?php echo trim($date[$n]);?></td>
    </tr>
    <?php
    }

?>
</tbody>
</table>
</div>