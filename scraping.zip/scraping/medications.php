<?php
include("header.php");
use Symfony\Component\DomCrawler\Crawler;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);
$year = array("2023", "2022");

$date=[];
$Barcode=[];
$prescriptionno=[];
$medicinename=[];
$dosage=[];
$period=[];
$usagemethod=[];
$usagenumber=[];
$boxcount=[];
$hospitalname=[];
$clinicname=[];

for($j = 0;$j < count($year);$j++) {
   $medications[$j]=$client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaGoreIlacGetir?year='.$year[$j].'');
   $date[] = $medications[$j]->filter('tr td:nth-child(1)')->each(function (Crawler $node, $i): string {
      return $node->text();
  });
  $barcode[] = $medications[$j]->filter('tr td:nth-child(2)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$prescriptionno[] = $medications[$j]->filter('tr td:nth-child(3)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$medicinename[] = $medications[$j]->filter('tr td:nth-child(4)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$dosage[] = $medications[$j]->filter('tr td:nth-child(5)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$period[] = $medications[$j]->filter('tr td:nth-child(6)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$usagemethod[] = $medications[$j]->filter('tr td:nth-child(7)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$usagenumber[] = $medications[$j]->filter('tr td:nth-child(8)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$boxcount[] = $medications[$j]->filter('tr td:nth-child(9)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$hospitalname[] = $medications[$j]->filter('tr td:nth-child(10)')->each(function (Crawler $node, $i): string {
   return $node->text();
});
$clinicname[] = $medications[$j]->filter('tr td:nth-child(11)')->each(function (Crawler $node, $i): string {
   return $node->text();
});


}

?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Prescription Date</th>
      <th scope="col">Barcode </th>
      <th scope="col">Prescription Number</th>
      <th scope="col">Medicine Name</th> <th scope="col">Dosage</th> <th scope="col">Period</th> <th scope="col">Usage Method</th> <th scope="col">Usage Number</th>
      <th scope="col">Box Count</th><th scope="col">Hospital Name</th><th scope="col">Clinic Name</th>
    </tr>
  </thead>
  <tbody>
    <?php 
for($j = 0;$j < count($year);$j++) {
    for($n = 0;$n < count($date[$j]);$n++) {
        ?>
    <tr>
        <td><?php echo $date[$j][$n];?> </td>
        <td><?php echo $barcode[$j][$n];?></td>
        <td><?php echo $prescriptionno[$j][$n];?></td>
        <td><?php echo $medicinename[$j][$n];?></td>
        <td><?php echo $dosage[$j][$n];?></td>
        <td><?php echo $period[$j][$n];?></td>
        <td><?php echo $usagemethod[$j][$n];?></td>
        <td><?php echo $usagenumber[$j][$n];?></td>
        <td><?php echo $boxcount[$j][$n];?></td>
        <td><?php echo $hospitalname[$j][$n];?></td>
        <td><?php echo $clinicname[$j][$n];?></td>
    </tr>
    <?php
    }
}
?>
</tbody>
</table>
</div>