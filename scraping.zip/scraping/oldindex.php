<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'vendor/autoload.php';
use Goutte\Client;
use Symfony\Component\HttpClient\HttpClient;

$client = new Client(HttpClient::create(['timeout' => 200]));
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);
$crawler1=$client->request('GET', 'https://enabiz.gov.tr/Profil/Index');

// split name in 2 parts label firstname, lastname
// trim all spaces from all texts and remove empty lines, so have trim function everywhere

$form = $crawler1->filter('#profil-duzenle-form')->form();

$records = $form->getValues();
//print_r($records);
$prersonalinfo=[];
foreach($records as $x => $val) 
{
   if($x=='Adi' || $x=='Soyadi' || $x=='TCKimlikNo' || $x=='TCKimlikNo' || $x=='DogumYeri' || $x=='DogumTarihi' || $x=='YasadigiSehir'
   || $x=='YasadigiUlke' || $x=='BirincilEmail' || $x=='BirincilTel' || $x=='Boy' || $x=='KanGrubu')
   {
    $prersonalinfo[$x]=$val;
   }

}
//print_r($prersonalinfo);
foreach($prersonalinfo as $key =>$value)
{
    if($key=='Adi') { echo "Firstname:".$value;} if($key=='Soyadi') { echo "Lastname:".$value;}  if($key=='TCKimlikNo') { echo "TCKimlikNo:".$value;} 
    if($key=='DogumYeri') { echo "DogumYeri:".$value;}  if($key=='DogumTarihi') { echo "DogumTarihi:".$value;} if($key=='YasadigiSehir') { echo "YasadigiSehir:".$value;} 
    if($key=='YasadigiUlke') { echo "YasadigiUlke:".$value;} if($key=='BirincilEmail') { echo "BirincilEmail:".$value;} 
    if($key=='BirincilTel') { echo "BirincilTel:".$value;} if($key=='Boy') { echo "Boy:".$value;} if($key=='KanGrubu') { echo "KanGrubu:".$value;} 
}
exit;

$firstname=$crawler1->filter('.profile-usermenu.ProfilResim ul li:nth-child(1) label:nth-of-type(1)')->text();

$lastname=$crawler1->filter('.profile-usermenu.ProfilResim ul li:nth-child(1) label:nth-of-type(2)')->text();

// citizenship number tcNumber 
$tcNumber=$crawler1->filter('.profile-usermenu.ProfilResim ul li:nth-child(2) a')->text();
 
// birthdate
$birthdate=$crawler1->filter('.profile-usermenu.ProfilResim ul li:nth-child(3) a')->text();

// birthplace
$birthplace=$crawler1->filter('.profile-usermenu.ProfilResim ul li:nth-child(4) a')->text();



/*personal information */
$email=$crawler1->filter('#divEMail .profile-info-box h3 label')->text();
$phone=$crawler1->filter('#divTel .profile-info-box h3 label')->text();
//$country=$crawler1->filter('body')->children('.profile-info-box #select2-Ulke-container')->text();
$crawler1->filter('select#KanGrubu option:selected')->each(function ($node) {
    print $node->text()."<br>";
});

echo trim($firstname)."<br>";
echo trim($lastname)."<br>";
echo trim($birthdate)."<br>";
echo trim($birthplace)."<br>";
echo trim($email)."<br>";
echo trim($phone)."<br>";

/*Get information from second page Visit  */



$visit=$client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/Index');

$visit->filter('#AnaContent #yetkiGrubu .portlet.light')->each(function ($node) {
    print $node->text()."\n";
});

?>