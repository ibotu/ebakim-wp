<script src="https://kit.fontawesome.com/a7b377beb0.js" crossorigin="anonymous"></script>
<style>
.rating {
    unicode-bidi: bidi-override;
    direction: rtl;
    font-size: 20px;
    display: inline-block;
}
.rating a.star {
    font-family: FontAwesome;
    font-weight: normal;
    font-style: normal;
    color: #000 !important;
    display: inline-block;
    text-decoration: none;
}
.rating a.star:before {
    content: "\f006";
    padding-right: 5px;
    color: #999999;
}
td label
{
    display: none;
}
.rating a.star:hover:before, .rating a.star:hover ~ a.star:before, .rating a.active:before, .rating a.active ~ a.active:before {
    content: "\f005";
    color: #f39200;
}
</style>
<?php 
include "header.php";
use Symfony\Component\DomCrawler\Crawler;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);

$year = array("2023", "2022");
$visitdate=[];
$clinicadd=[];
$clinicname=[];
$physicianname=[];
$trackingno=[];
$rating=[];
for($j = 0;$j < count($year);$j++) {
    $visit[$j] = $client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaGoreZiyaretGetir?year='.$year[$j].'');

    $visitdate[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body div:nth-child(1)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $clinicadd[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body h3')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $clinicname[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body div:nth-of-type(2)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $physicianname[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body div:nth-of-type(3)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $trackingno[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body div:nth-of-type(4)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $rating[] = $visit[$j]->filter('tr td div.portlet.light div.portlet-body div.form-group')->each(function (Crawler $node, $i) {
        return $node->html();
    });
}
?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Clinic Address </th>
      <th scope="col">Clinic Name</th>
      <th scope="col">physcianname</th> 
      <th scope="col">Hospital Tracking No.</th>
     <th scope="col">Evaluation</th>
    </tr>
  </thead>
  <tbody>
    <?php 
for($j = 0;$j < count($year);$j++) {
    for($n = 0;$n < count($visitdate[$j]);$n++) {
        ?>
    <tr>
        <td><?php echo trim($visitdate[$j][$n]);?> </td>
        <td><?php echo trim($clinicadd[$j][$n]);?></td>
        <td><?php echo trim(str_replace("Klinik Adı:", "", $clinicname[$j][$n]));?></td>
        <td><?php echo trim(str_replace("Hekim Adı:", "", $physicianname[$j][$n]));?></td>
        <td><?php echo trim(str_replace("Hastane Takip No:", "", $trackingno[$j][$n]));?></td>
        <td><?php echo $rating[$j][$n];?></td>
    </tr>
    <?php
    }
}
?>
</tbody>
</table>
</div>
