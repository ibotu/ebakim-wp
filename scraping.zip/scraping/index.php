<?php include_once "header.php"?>

<?php



// Create a CookieJar with some predefined cookies
/*
$cookieJar = new CookieJar(false, [
  [
      'Name'     => 'test_cookie_name',
      'Value'    => 'test_cookie_value',
      'Domain'   => 'example.com',
      'Path'     => '/',
      'Max-Age'  => '86400',
      'Expires'  => time() + 86400,
  ],
]);
*/

// Instantiate the Guzzle Client with the CookieJar
/* $guzzleClient = new GuzzleClient([
  'timeout' => 200,
  //'cookies' => $cookieJar,
  // ... other configurations
]);
*/

$crawler = $client->request('GET', 'https://enabiz.gov.tr/');

// click login
$form = $crawler->selectButton('btnGiris')->form();
// submit the form with valid credentials
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);

$records = $form->getValues();
//print_r($records);
if($records['__RequestVerificationToken']!='')
{
    echo '<div class="container"> <h3> welcome to scraping section</h3>';
  echo '</div>';
}
else
{
    echo "trigger login function code again";
}
// navigate to the next page with cookiejar


?>
</body>
</html>