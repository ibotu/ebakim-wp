<?php 
include "header.php";
use Symfony\Component\DomCrawler\Crawler;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);
$myreports=$client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaGoreRaporGetir');
$date = $myreports->filter('tr td:nth-child(1)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$reportname = $myreports->filter('tr td:nth-child(2)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$reporttrackingno = $myreports->filter('tr td:nth-child(3)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$reporttype = $myreports->filter('tr td:nth-child(4)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$startingdate = $myreports->filter('tr td:nth-child(5)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$enddate = $myreports->filter('tr td:nth-child(6)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
$diagnosis = $myreports->filter('tr td:nth-child(7)')->each(function (Crawler $node, $i): string {
    return $node->text();
});
?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Report Number</th>
      <th scope="col">Report Tracking Number</th>
      <th scope="col">Report Type</th> 
      <th scope="col">Starting Date</th> 
      <th scope="col">End Date</th> 
      <th scope="col">Diagnosis</th> 
    </tr>
  </thead>
  <tbody>
    <?php 
for($n = 0;$n < count($date);$n++) {
    ?>
    <tr>
        <td><?php echo trim($date[$n]);?> </td>
        <td><?php echo trim($reportname[$n]);?></td>
        <td><?php echo trim($reporttrackingno[$n]);?></td>
        <td><?php echo trim($reporttype[$n]);?></td>
        <td><?php echo trim($startingdate[$n]);?></td>
        <td><?php echo trim($enddate[$n]);?></td>
        <td><?php echo trim($diagnosis[$n]);?></td>
    </tr>
    <?php
}
?>
</tbody>
</table>
</div>
