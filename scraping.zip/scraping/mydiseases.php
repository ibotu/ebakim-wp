<?php 
include "header.php";
use Symfony\Component\DomCrawler\Crawler;
$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);

$year = array("2023", "2022");
$date=[];
$diagnosis=[];
$clinic=[];
$physician=[];
for($j = 0;$j < count($year);$j++) {
    $mydisease[$j] = $client->request('GET', 'https://enabiz.gov.tr/HastaBilgileri/YillaraGoreHastalikGetir?year='.$year[$j].'');

    $date[] = $mydisease[$j]->filter('tr.odd > td:nth-child(1)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $diagnosis[] = $mydisease[$j]->filter('tr.odd > td:nth-child(2)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $clinic[] = $mydisease[$j]->filter('tr.odd > td:nth-child(3)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
    $physician[] = $mydisease[$j]->filter('tr.odd > td:nth-child(4)')->each(function (Crawler $node, $i): string {
        return $node->text();
    });
}

?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Diagnosis</th>
      <th scope="col">Clinic</th>
      <th scope="col">Physician</th> 
    </tr>
  </thead>
  <tbody>
    
    <?php 
for($j = 0;$j < count($year);$j++) {
    for($n = 0;$n < count($date[$j]);$n++) {

        ?>
    <tr>
        <td><?php echo trim($date[$j][$n]);?> </td>
        <td><?php echo trim($diagnosis[$j][$n]);?></td>
        <td><?php echo trim($clinic[$j][$n]);?></td>
        <td><?php echo trim($physician[$j][$n]);?></td>
    </tr>
    <?php
    }
}
?>
</tbody>
</table>
</div>