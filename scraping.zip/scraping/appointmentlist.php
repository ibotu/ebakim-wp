<?php 
include "header.php";

$crawler = $client->request('GET', 'https://enabiz.gov.tr/');
$form = $crawler->selectButton('btnGiris')->form();
$crawler = $client->submit($form, ['TCKimlikNo' => '43564225540', 'Sifre' => 'Welcome2023!']);
$url='https://enabiz.gov.tr/Randevular/Randevular';
$crawler = $client->request('GET', $url);
$jsonResponse = $client->getResponse()->getContent();
$data = json_decode($jsonResponse, true);
?>
<div class="container">
<table class="table table-hover">
<thead>
    <tr><th scope="col">Date/Time</th> <th scope="col">Instituation</th> <th scope="col">Clinic Name</th>
      <th scope="col">Expamination Place</th> <th scope="col">Physcian.</th>  <th scope="col">Status</th> <th scope="col"> Appointment Hrn</th>
    </tr>
  </thead>
  <tbody>
    <?php 
for($n = 0;$n < count($data);$n++) {
    ?>
    <tr>
        <td><?php echo trim($data[$n]['tarih']);?></td>
        <td><?php echo trim($data[$n]['hastane']);?></td>
        <td><?php echo trim($data[$n]['brans']);?></td>
        <td><?php echo trim($data[$n]['altKlinik']);?></td>
        <td><?php echo trim($data[$n]['doktor']);?></td>
        <td>
          <?php 
        if(trim($data[$n]['durum'])==1) { echo "<label class='p-2 mb-2 bg-success text-white'>Active</label>"; } else {echo "<label class='p-2 mb-2 bg-danger text-white'>Past Appointment</label>";}?>
        </td>
        <td><?php echo trim($data[$n]['randevuHrn']);?></td>
       
    </tr>
    <?php
}
?>
</tbody>
</table>
</div>
