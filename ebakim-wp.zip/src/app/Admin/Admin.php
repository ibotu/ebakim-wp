<?php

namespace eBakim\Admin;

use eBakim\App;

class Admin
{

}
