<?php
/**
 * Plugin Name: eBakim
 * Plugin URI: https://fugenservices.com
 * Description: eBakim healthcare project
 * Author: Fugen Services
 * Version: 0.1.1
 * Author URI: https://fugenservices.com
 * Text Domain: ebakim-wp
 */

if (!defined('WPINC')) {
    exit; // direct access
}

require_once __DIR__ . '/src/app/App.php';

// (new \eBakim\App(__FILE__))->setup();

