Run "composer install" inside plugin/src directory.
